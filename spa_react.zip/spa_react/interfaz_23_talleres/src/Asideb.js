import React, { Component } from 'react';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

class Asideb extends Component {
  render() {
    return (
      <div className="Asideb">
        <header >
          <h1 >Maestros taller Algoritmos</h1>
        </header>
        <p >
          <code>Sólo personal autorizado</code>
        </p>


<MuiThemeProvider>
       
    <Table>
    <TableHeader>
      <TableRow>
        <TableHeaderColumn>Hora</TableHeaderColumn>
        <TableHeaderColumn>Nombre</TableHeaderColumn>
        <TableHeaderColumn>Aula</TableHeaderColumn>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow>
        <TableRowColumn>12:00</TableRowColumn>
        <TableRowColumn>Mario Jimenez</TableRowColumn>
        <TableRowColumn>Activo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>13:00</TableRowColumn>
        <TableRowColumn>Pedro Martínez</TableRowColumn>
        <TableRowColumn>Activo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>9:00</TableRowColumn>
        <TableRowColumn>Karina Butron</TableRowColumn>
        <TableRowColumn>Activo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>10:00</TableRowColumn>
        <TableRowColumn>Marina Flores</TableRowColumn>
        <TableRowColumn>Activo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>11:00</TableRowColumn>
        <TableRowColumn>Cristina Durham</TableRowColumn>
        <TableRowColumn>Inactivo</TableRowColumn>
      </TableRow>
    </TableBody>
  </Table>
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Asideb;