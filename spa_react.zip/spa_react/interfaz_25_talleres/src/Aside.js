import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import elon_musk from './elon_musk.jpg';
import {Card, CardActions, CardHeader, CardMedia, CardTitle, CardText} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';


class Aside extends Component {
  render() {
    return (
      <div className="Aside">
        <header >
          <h1 >Nueva Taller Elon Musk</h1>
        </header>
        <p >
          
        </p>


        <MuiThemeProvider>
       <Card>
    <CardHeader
      
      avatar={elon_musk} />
    <CardMedia
      overlay={<CardTitle title="Elon Musk" subtitle="Tesla Motors" />}
    >
      <img src="images/nature-600-337.jpg" alt="" />
    </CardMedia>
    <CardTitle title="Desea comprar" subtitle="Software y mucho software" />
    <CardText>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
      Donec mattis pretium massa. Aliquam erat volutpat. Nulla facilisi.
      Donec vulputate interdum sollicitudin. Nunc lacinia auctor quam sed pellentesque.
      Aliquam dui mauris, mattis quis lacus id, pellentesque lobortis odio.
    </CardText>
    <CardActions>
      <FlatButton label="Contactar" />
      <FlatButton label="Rechazar" />
    </CardActions>
  </Card>
   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Aside;