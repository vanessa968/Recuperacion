import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';




class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Pendientes</h1>
        </header>
        


        <MuiThemeProvider>
         <Table>
    <TableHeader>
      <TableRow>
        <TableHeaderColumn>Cantidad</TableHeaderColumn>
        <TableHeaderColumn>Nombre</TableHeaderColumn>
        <TableHeaderColumn>Estado</TableHeaderColumn>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow>
        <TableRowColumn>$18,000,000,000</TableRowColumn>
        <TableRowColumn>Epn</TableRowColumn>
        <TableRowColumn>Fugitivo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>$7,980,000,000</TableRowColumn>
        <TableRowColumn>Luis Videgaray</TableRowColumn>
        <TableRowColumn>Fugitivo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>$6,000,000,000</TableRowColumn>
        <TableRowColumn>Osorio Chong</TableRowColumn>
        <TableRowColumn>Fugitivo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>$30,000,000,000</TableRowColumn>
        <TableRowColumn>Carlos Salinas de Gortari</TableRowColumn>
        <TableRowColumn>Fugitivo</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>$100,000,000</TableRowColumn>
        <TableRowColumn>Desconocido</TableRowColumn>
        <TableRowColumn>Desconocido</TableRowColumn>
      </TableRow>
    </TableBody>
  </Table>
   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;