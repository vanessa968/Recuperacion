import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import RefreshIndicator from 'material-ui/RefreshIndicator';
import IconMenu from 'material-ui/IconMenu';
import IconButton from 'material-ui/IconButton';
import FontIcon from 'material-ui/FontIcon';
import NavigationExpandMoreIcon from 'material-ui/svg-icons/navigation/expand-more';
import MenuItem from 'material-ui/MenuItem';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';


class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Tablas de presupuesto</h1>
          <p>Cargando tablas</p>
        </header>
        
        <MuiThemeProvider>
            <Table>
    <TableHeader>
      <TableRow>
        <TableHeaderColumn>Presupuesto</TableHeaderColumn>
        <TableHeaderColumn>Empresa</TableHeaderColumn>
        <TableHeaderColumn>País</TableHeaderColumn>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow>
        <TableRowColumn>100,000,000</TableRowColumn>
        <TableRowColumn>Saint Laurent</TableRowColumn>
        <TableRowColumn>Netherlands</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>200,000,000</TableRowColumn>
        <TableRowColumn>Samsung </TableRowColumn>
        <TableRowColumn>South Korea</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>188,000</TableRowColumn>
        <TableRowColumn>Chess Network</TableRowColumn>
        <TableRowColumn>Netherlands</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>500,000,000</TableRowColumn>
        <TableRowColumn>Pepsico</TableRowColumn>
        <TableRowColumn>México</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>200,000</TableRowColumn>
        <TableRowColumn>Teaching English </TableRowColumn>
        <TableRowColumn>United States</TableRowColumn>
      </TableRow>
    </TableBody>
  </Table>
   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;