import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';


const styles = {
  customWidth: {
    width: 150,
  },
};



class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Dejanos tu opinión</h1>
        </header>
        


        <MuiThemeProvider>
        <div>
    <TextField
      hintText="Te gusta nuestro servicio"
    /><br />
    <br />
    <TextField
      hintText="Has sufrido alguna falla de nuestro servicio"
    /><br />
    <TextField
      id="text-field-default"
      defaultValue="Dejanos un comentario"
    /><br />
    <TextField
      hintText="* Si es todo"
      floatingLabelText="Lo que mas te gusta de nuestra empresa"
    /><br />
    <TextField
      defaultValue="Nombre Completo"
      floatingLabelText="Alguien te recomendó?"
    /><br />
    <TextField
      hintText="Dinos"
      floatingLabelText="Como podemos ayudarte"
      floatingLabelFixed={true}
    /><br />
    
    <TextField
      hintText="Agrega mas opiniones"
      fullWidth={true}
    />
  </div>
   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;