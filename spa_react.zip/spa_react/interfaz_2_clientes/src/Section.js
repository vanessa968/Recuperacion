import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';


class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Administrar Clientes</h1>
        </header>
        <p >
          <code>Lo siento no puede modificar, Sólo personal autorizado</code>
        </p>


<MuiThemeProvider>
       
   <div>
    <TextField
      disabled={true}
      hintText="No puedes editar"
    /><br />
    <TextField
      disabled={true}
      id="text-field-disabled"
      defaultValue="No puedes editar acceso denegado"
    /><br />
    <TextField
      disabled={true}
      hintText="Disabled Hint Text"
      floatingLabelText="No puedes modificar"
    /><br />
    <TextField
      disabled={true}
      hintText="Nombre de Usuario"
      defaultValue="Desactivado"
      floatingLabelText="Floating Label Text"
    />
  </div>
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;