import React, { Component } from 'react';
import Badge from 'material-ui/Badge';
import IconButton from 'material-ui/IconButton';
import NotificationsIcon from 'material-ui/svg-icons/social/notifications';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './misEstilos.css';

class Header extends Component {
  render() {
    return (
      <div className=" Header ">
          
                <div classname="logo"><h1>Clientes</h1></div>

                <div classname="barraBusqueda"> <MuiThemeProvider>  <div>
             <Badge badgeContent={4} primary={true}>
      <NotificationsIcon />
    </Badge>
    <Badge
      badgeContent={10}
      secondary={true}
      badgeStyle={{top: 12, right: 12}}
    >
      <IconButton tooltip="Notifications">
        <NotificationsIcon />
      </IconButton>
    </Badge>
  </div></MuiThemeProvider></div>
          </div>
      
    );
  }
}

export default Header;
