import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import RaisedButton from 'material-ui/RaisedButton';
import './misEstilos.css';


class Aside extends Component {
  render() {
    return (
      <div classname="Aside">
        <MuiThemeProvider>
        <h1>Ventas del mes</h1>
        <RaisedButton label="Software" fullWidth={true} />
        <RaisedButton label="Hardware" fullWidth={true} />
        <RaisedButton label="Soporte" fullWidth={true} />
        <RaisedButton label="Redes" fullWidth={true} />
        <RaisedButton label="Otros" fullWidth={true} />

        </MuiThemeProvider>
      </div>
    );
  }
}

export default Aside;