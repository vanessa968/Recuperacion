import React from 'react';
import ReactDOM from 'react-dom';
import Header from './Header';
import Nav from './Nav';
import Section from './Section';
import Aside from './Aside';
import Footer from './Footer';
import registerServiceWorker from './registerServiceWorker';




ReactDOM.render(<Header />, document.getElementById('header'));
ReactDOM.render(<Nav />, document.getElementById('nav'));
ReactDOM.render(<Section />, document.getElementById('section'));
ReactDOM.render(<Footer />, document.getElementById('footer'));


registerServiceWorker();
