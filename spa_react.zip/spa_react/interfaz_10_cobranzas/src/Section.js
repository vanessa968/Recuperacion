import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';
import Slider from 'material-ui/Slider';
import Avatar from 'material-ui/Avatar';
import Chip from 'material-ui/Chip';
import FontIcon from 'material-ui/FontIcon';
import face from './face.png';
import {blue300, indigo900} from 'material-ui/styles/colors';

const styles = {
  chip: {
    margin: 4,
  },
  wrapper: {
    display: 'flex',
    flexWrap: 'wrap',
  },
};

function handleRequestDelete() {
  alert('You clicked the delete button.');
}

function handleTouchTap() {
  alert('You clicked the Chip.');
}


class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Pendientes</h1>
        </header>
        


        <MuiThemeProvider>
         <div style={styles.wrapper}>

        <Chip
          style={styles.chip}
        >
          Text Chip
        </Chip>

        <Chip
          onRequestDelete={handleRequestDelete}
          onClick={handleTouchTap}
          style={styles.chip}
        >
          Gobierno del Estado de Tamaulipas
        </Chip>

        <Chip
          onClick={handleTouchTap}
          style={styles.chip}
        >
          <Avatar src={face} />
          India stock Market
        </Chip>

        <Chip
          onRequestDelete={handleRequestDelete}
          onClick={handleTouchTap}
          style={styles.chip}
        >
          <Avatar src={face} />
          Sabritas
        </Chip>

        

        

        <Chip onClick={handleTouchTap} style={styles.chip}>
          <Avatar size={32}>A</Avatar>
          Pepsico
        </Chip>

        <Chip
          backgroundColor={blue300}
          onRequestDelete={handleRequestDelete}
          onClick={handleTouchTap}
          style={styles.chip}
        >
          <Avatar size={32} color={blue300} backgroundColor={indigo900}>
            SSG
          </Avatar>
          Samsung
        </Chip>
      </div>
   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;