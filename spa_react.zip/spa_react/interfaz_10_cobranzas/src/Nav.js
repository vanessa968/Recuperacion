import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
            <FlatButton label="Pendientes"primary={true} />
   			    <FlatButton label="En espera" primary={true} />
  			    <FlatButton label="Intereses" primary={true} />
  			    <FlatButton label="Registrar nueva" primary={true} />

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
