import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';


const styles = {
  customWidth: {
    width: 150,
  },
};



class Section extends Component {
  state = {
    value: 1,
  };

  handleChange = (event, index, value) => this.setState({value});
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Registrar nuevo presupuesto</h1>
        </header>
        


        <MuiThemeProvider>
           <div>
        <SelectField
          floatingLabelText="Continente"
          value={this.state.value}
          onChange={this.handleChange}
        >
          <MenuItem value={1} primaryText="America" />
          <MenuItem value={2} primaryText="Europa" />
          <MenuItem value={3} primaryText="Asia" />
          <MenuItem value={4} primaryText="Oceania" />
          <MenuItem value={5} primaryText="Africa" />
        </SelectField>
        <br />
        <SelectField floatingLabelText="País" value={1} disabled={true}>
          <MenuItem value={1} primaryText="Democrático" />
          <MenuItem value={2} primaryText="Socialista" />
        </SelectField>
        <br />
        <SelectField
          floatingLabelText="Cantidad"
          value={this.state.value}
          onChange={this.handleChange}
          style={styles.customWidth}
        >
          <MenuItem value={1} primaryText="+500,000" />
          <MenuItem value={2} primaryText="350k - 499k" />
          <MenuItem value={3} primaryText="250k - 349k" />
          <MenuItem value={4} primaryText="100k - 150k" />
          <MenuItem value={5} primaryText="<100,000" />
        </SelectField>
        <br />
        <SelectField
          floatingLabelText="Frequencia"
          value={this.state.value}
          onChange={this.handleChange}
          autoWidth={true}
        >

          <MenuItem value={1} primaryText="Anual" />
          <MenuItem value={2} primaryText="Semestral" />
          <MenuItem value={3} primaryText="cuatrimestre" />
          <MenuItem value={4} primaryText="Trinal" />
        </SelectField>
      </div>

   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;