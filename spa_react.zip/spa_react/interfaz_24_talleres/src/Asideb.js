import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import {Card, CardActions, CardHeader, CardMedia, CardTitle, CardText} from 'material-ui/Card';
import Slider from 'material-ui/Slider';


class Asideb extends Component {
  render() {
    return (
      <div className="Asideb">
        <header >
          <h1 >Califica el taller de mecatrónica</h1>
        </header>
      


        <MuiThemeProvider>
       <div>
    <h3>Estoy Satisfecho con mi desempeño</h3>   
    <Slider />
    <h3>Estoy Satisfecho con mi anterior semestre</h3>
    <Slider defaultValue={0.5} />
    <h3>Responsabilidades del profesor</h3>
    <Slider defaultValue={1} />
  </div>
   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Asideb;