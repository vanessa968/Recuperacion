import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';
import FlatButton from 'material-ui/FlatButton';


class Acidec extends Component {
  render() {
    return (
      <div className="Acidec">
        <header >
          <h1 >Tendencias</h1>
        </header>
        


        <MuiThemeProvider>
         
          <TextField
           hintText="Cantidad de adeudo"
            floatingLabelText="Introduce aqui para calcular interés"
           floatingLabelFixed={true}/><br />
          <FlatButton label="Calcular interés" />

        </MuiThemeProvider>

      </div>
    );
  }
}

export default Asidec;