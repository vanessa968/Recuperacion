import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import Paper from 'material-ui/Paper';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';
import './misEstilos.css';


class Aside extends Component {
  render() {
    return (
      <div>
        <MuiThemeProvider>
        <Paper classname="Aside">
          <Menu>
        <MenuItem primaryText="Clientes nuevos" />
        <MenuItem primaryText="Nuevo sistema" />
        <MenuItem primaryText="Lo más interesante" />
        <MenuItem primaryText="Clientes por comisión " />
        </Menu>
        </Paper>
        </MuiThemeProvider>
      </div>
    );
  }
}

export default Aside;