import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './misEstilos.css';

class Header extends Component {
  render() {
    return (
      <div className="App Header container">
          <div classname="row">
                <div classname="logo"><h1>Clientes</h1></div>

                <div classname="barraBusqueda"> <MuiThemeProvider> <TextField hintText="Buscar"/><br /><br /></MuiThemeProvider></div>
          </div>
      </div>
    );
  }
}

export default Header;
