import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Agregar un nuevo cliente</h1>
        </header>
        <p >
          Por favor rellena todos los campos.
        </p>

<MuiThemeProvider>
        <TextField
      hintText="Nombre Completo"
    /><br />
    <br />
    <TextField
      hintText="Lugar de Nacimiento"
    /><br />
    
    <TextField
      hintText="Introduzca separada por comas"
      floatingLabelText="Preferencias"
    /><br />
    <TextField
      defaultValue="Calle, Número, Código Postal"
      floatingLabelText="Domicilio"
    /><br />
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;