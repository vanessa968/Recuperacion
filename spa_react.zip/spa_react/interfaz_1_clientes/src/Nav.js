import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
            <FlatButton label="Agregar Cliente" />
             
   			 <FlatButton label="Estadisticas" primary={true} />
  			 <FlatButton label="Administrar Clientes" secondary={true} />
  			 <FlatButton label="Borrar Cliente" disabled={true} />

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
