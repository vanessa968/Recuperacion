import React, { Component } from 'react';
import graficas from  './graficas.png';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';



class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Realiza tu reporte</h1>
          
                 </header>

                 <MuiThemeProvider>
        <TextField
      hintText="Lugar"
      fullWidth={true}
    />

    <TextField
      hintText="Acciones a recalcar"
      fullWidth={true}
    />

    <TextField
      hintText="Fuentes"
      fullWidth={true}
    />

    <TextField
      hintText="Mas información"
      fullWidth={true}
    />
            </MuiThemeProvider>


      </div>
    );
  }
}

export default Section;