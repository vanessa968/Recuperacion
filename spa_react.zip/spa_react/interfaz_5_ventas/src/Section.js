import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TimePicker from 'material-ui/TimePicker';


class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Ventas</h1>
        </header>
        <p >
          <code>Antes de empezar por favor selecciona la hora</code>
        </p>


<MuiThemeProvider>
       
   <div>
    <TimePicker
      hintText="Hora de entrada"
    />
    
  </div>
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;