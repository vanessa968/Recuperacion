import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
            <FlatButton label="Ventas pendientes"primary={true} />
             
   			 <FlatButton label="Nuevas peticiones" primary={true} />
  			 <FlatButton label="Ultimos resultados" primary={true} />
  			 <FlatButton label="Las mejores Ventas" primary={true} />

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
