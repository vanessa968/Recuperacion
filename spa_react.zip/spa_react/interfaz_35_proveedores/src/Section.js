import React, { Component } from 'react';
import graficas from  './graficas.png';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';



class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Editar Provedor</h1>
          
                 </header>

                 <MuiThemeProvider>
        <Table>
    <TableHeader>
      <TableRow>
        <TableHeaderColumn>Empresa</TableHeaderColumn>
        <TableHeaderColumn>Nombre</TableHeaderColumn>
        <TableHeaderColumn>País</TableHeaderColumn>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow>
        <TableRowColumn>Tesla Motors</TableRowColumn>
        <TableRowColumn>John Smith</TableRowColumn>
        <TableRowColumn>United States</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>Cemex</TableRowColumn>
        <TableRowColumn>Pedro Marín</TableRowColumn>
        <TableRowColumn>México</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>Samsung Galaxy</TableRowColumn>
        <TableRowColumn>Stephanie Sanders</TableRowColumn>
        <TableRowColumn>South Korea</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>Nvidia </TableRowColumn>
        <TableRowColumn>Steve Brown</TableRowColumn>
        <TableRowColumn>United States</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>Qualcomm</TableRowColumn>
        <TableRowColumn>Xin Zhao</TableRowColumn>
        <TableRowColumn>China</TableRowColumn>
      </TableRow>
    </TableBody>
  </Table>
            </MuiThemeProvider>
            


      </div>
    );
  }
}

export default Section;