import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';
import FlatButton from 'material-ui/FlatButton';



class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Intereses</h1>
        </header>
        


        <MuiThemeProvider>
           <TextField
           hintText="Cantidad de adeudo"
            floatingLabelText="Introduce aqui para calcular interés"
           floatingLabelFixed={true}/><br />
          <FlatButton label="Calcular interés" />

   
        </MuiThemeProvider>

      </div>
    );
  }
}

export default Section;