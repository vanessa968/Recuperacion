import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
           <FlatButton label="Registrar nuevo proveedor" primary={true} />
            <FlatButton label="Buscar Proveedor"primary={true} />
   			    <FlatButton label="Editar proveedor" primary={true} />
  			    

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
