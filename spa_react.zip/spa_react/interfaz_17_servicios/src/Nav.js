import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
           <FlatButton label="Servicios de hosting" primary={true} />
            <FlatButton label="Servicios de coaching"primary={true} />
   			    <FlatButton label="Contrataciones" primary={true} />
  			    <FlatButton label="Servicios logisticos" primary={true} />
  			    

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
