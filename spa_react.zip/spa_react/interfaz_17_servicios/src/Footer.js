import React, { Component } from 'react';
import './misEstilos.css';


class Footer extends Component {
  render() {
    return (
      <div className="Footer">
        
          
          <h1 >Todos los Derechos Reservados Servicios</h1>
          <p> <h2>Contacto:</h2><code>soporte@servicios.com</code></p>
       
        
      </div>
    );
  }
}

export default Footer;