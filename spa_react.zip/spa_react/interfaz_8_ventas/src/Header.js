import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './misEstilos.css';
import logo_ventas from './logo_ventas.png';

class Header extends Component {
  render() {
    return (
      <div className="Header">
        <header className="App-header">
          <img src={logo_ventas} className="App-logo" alt="logo" />
          <h1 className="App-title">Ventas</h1>
        </header>
        </div>
      
    );
  }
}

export default Header;
