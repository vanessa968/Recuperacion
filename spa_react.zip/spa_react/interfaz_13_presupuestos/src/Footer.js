import React, { Component } from 'react';
import './misEstilos.css';


class Footer extends Component {
  render() {
    return (
      <div className="Footer">
        
          
          <h1 >Todos los Derechos Reservados Presupuestos</h1>
          <p> <h2>Contacto:</h2><code>soporte@presupuestos.com</code></p>
       
        
      </div>
    );
  }
}

export default Footer;