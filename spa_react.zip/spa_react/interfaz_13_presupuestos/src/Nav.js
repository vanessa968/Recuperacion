import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
           <FlatButton label="Actualidad" primary={true} />
            <FlatButton label="Presupuestos historial"primary={true} />
   			    <FlatButton label="Presupuestos futuros" primary={true} />
  			    <FlatButton label="Inversiones" primary={true} />
  			    

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
