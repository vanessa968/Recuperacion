import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
           <FlatButton label="Talleres Nuevos" primary={true} />
            <FlatButton label="Taller de Mantenimento"primary={true} />
   			    <FlatButton label="Taller de actualización" primary={true} />
  			    <FlatButton label="Taller de servicios web" primary={true} />
  			    

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
