import React, { Component } from 'react';
import graficas from  './graficas.png';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';



class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Registra nuevo proveedor</h1>
          
                 </header>

                 <MuiThemeProvider>
        <TextField
      defaultValue="Ej. Martín"
      floatingLabelText="Introduce Nombre "/>
    <TextField
      defaultValue="Ej. Telmex"
      floatingLabelText="Introduce Empresa" />
    <TextField
      defaultValue="Ej. Mineria"
      floatingLabelText="Introduce palabras clave" />
      <TextField
      defaultValue="Ej. Madera"
      floatingLabelText="Introduce Producto "/>
    <TextField
      defaultValue="Ej. México"
      floatingLabelText="Introduce País" />
    <TextField
      defaultValue="Ej. Maritimo"
      floatingLabelText="Introduce palabras clave" />
            </MuiThemeProvider>
            


      </div>
    );
  }
}

export default Section;