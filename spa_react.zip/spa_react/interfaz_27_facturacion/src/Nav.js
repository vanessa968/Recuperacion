import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import './misEstilos.css';


class Nav extends Component {
  render() {
    return (
      <div className="Nav App">
           <MuiThemeProvider>
           <FlatButton label="Factura Online" primary={true} />
            <FlatButton label="Factura gratuita"primary={true} />
   			    <FlatButton label="Historial de facturas" primary={true} />
  			    <FlatButton label="Registros de facturas" primary={true} />
  			    

        </MuiThemeProvider>
                    
      </div>
    );
  }
}

export default Nav;
