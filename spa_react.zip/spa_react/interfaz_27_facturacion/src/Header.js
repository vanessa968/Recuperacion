import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './misEstilos.css';
import factura from './factura.png';

class Header extends Component {
  render() {
    return (
      <div className="Header">
        <header className="App-header">
          <img src={factura} className="App-logo" alt="logo" />
          <h1 className="App-title">Facturacion</h1>
        </header>
        </div>
      
    );
  }
}

export default Header;
