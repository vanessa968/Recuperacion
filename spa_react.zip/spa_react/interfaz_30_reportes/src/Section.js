import React, { Component } from 'react';
import graficas from  './graficas.png';



class Section extends Component {
  render() {
    return (
      <div className="Section">
        <header >
          <h1 >Reporte de ventas 2017</h1>
          <img src={graficas} className="App-logo" alt="logo" />
          <p>Un reporte es un informe o una noticia. Este tipo de documento (que puede ser impreso, digital, audiovisual, etc.) pretende transmitir una información, aunque puede tener diversos objetivos. Existen reportes divulgativos, persuasivos y de otros tipos.</p>
        </header>
        



      </div>
    );
  }
}

export default Section;