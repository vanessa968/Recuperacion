import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './misEstilos.css';
import reporte from './reporte.png';

class Header extends Component {
  render() {
    return (
      <div className="Header">
        <header className="App-header">
          <img src={reporte} className="App-logo" alt="logo" />
          <h1 className="App-title">Reportes</h1>
        </header>
        </div>
      
    );
  }
}

export default Header;
