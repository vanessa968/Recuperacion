import React, { Component } from 'react';
import factura from  './factura.jpg';


class Asider extends Component {
  render() {
    return (
      <div className="Asider">
        <header >
          <h1 >Facturacion 2017</h1>
          <img src={factura} className="App-logo" alt="logo" />
          <p>Una factura, factura de compra o factura comercial, es un documento mercantil que refleja toda la información de una operación de compraventa. La información fundamental que aparece en una factura debe reflejar la entrega de un producto o la provisión de un servicio, junto a la fecha de devengo, además de indicar la cantidad a pagar en relación a existencias, bienes de una empresa para su venta en eso ordinario de la explotación, o bien para su transformación o incorporación al proceso productivo, además de indicar el tipo de Impuesto sobre el Valor Añadido (IVA) que se debe aplicar.</p>
        </header>



      </div>
    );
  }
}

export default Asider;